export const API_BASE_URL = 'http://localhost:8000'
export const DASHBOARD_BASE_URL = 'http://localhost:5173'
export const USER_ID = 'demo-user'
export const ALERTS_POLL_MINUTES = 1
